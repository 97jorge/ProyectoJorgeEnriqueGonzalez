
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
   
    <title>Ferreteria Jorge</title>
</head>
<style>
 div{
    
  font-size: 50px;
    font-style: italic;
    background-color:aquamarine;
 }

</style>

<body>

<div>
    <h1>ferreteria jorge</h1>
</div>
    <h2>Aqui encuentras todo lo que necesitas</h2>

</body>
</html>