<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ferreteriaController extends Controller
{

    public function ferre(){
        return view('ferreteria');
    
    }
    //
}
